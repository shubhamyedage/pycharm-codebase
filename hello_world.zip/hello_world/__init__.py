# from app.hello_world import HelloWorld

def main():
    print("Hello world")
    # HelloWorld().run()