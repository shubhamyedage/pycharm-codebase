class HelloWorld:
    def run(self):
        print("Hello world.")