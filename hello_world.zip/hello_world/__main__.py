from __init__ import main

main()
