export FLASK_DEBUG=1
FLASK_APP=hello.py flask run